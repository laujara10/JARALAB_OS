# Marketing homepage UI kit

Editorial marketing homepage recreation — the brief's "premium editorial design... Apple, Linear, Stripe, Notion, Vercel" reference points, applied to JaraLab's positioning (financial clarity, AI copilot, business intelligence for restaurant owners). No source was attached; this is a first pass, not a copy of an existing site.

A product-screenshot area is left as an explicit placeholder (dashed border, labeled) rather than fabricated imagery — swap in a real dashboard screenshot.

Files: `MarketingHome.part.js`, `index.html`.
