function MarketingHome() {
  const { Button, Icon, Badge } = window.JaraLabDesignSystem_424ac8;
  return (
    <div style={{ fontFamily: 'var(--font-sans)', color: 'var(--fg-primary)', background: 'var(--bg-page)' }}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '20px var(--space-8)', borderBottom: '1px solid var(--border-subtle)' }}>
        <div style={{ fontWeight: 600, fontSize: 18, letterSpacing: 'var(--tracking-tight)' }}>JaraLab</div>
        <nav style={{ display: 'flex', gap: 28, fontSize: '0.875rem', color: 'var(--fg-secondary)' }}>
          <span>Product</span><span>Pricing</span><span>Customers</span><span>Company</span>
        </nav>
        <div style={{ display: 'flex', gap: 10 }}>
          <Button variant="ghost" size="sm">Log in</Button>
          <Button variant="primary" size="sm">Get started</Button>
        </div>
      </header>

      <section style={{ maxWidth: 760, margin: '0 auto', textAlign: 'center', padding: 'var(--space-32) var(--space-6) var(--space-16)' }}>
        <div style={{ fontSize: '0.75rem', fontWeight: 500, textTransform: 'uppercase', letterSpacing: 'var(--tracking-widest)', color: 'var(--fg-tertiary)', marginBottom: 'var(--space-4)' }}>AI-native restaurant intelligence</div>
        <h1 style={{ font: 'var(--text-display-xl)', letterSpacing: 'var(--tracking-tight)', margin: '0 0 var(--space-5)' }}>Your margins, explained.</h1>
        <p style={{ font: 'var(--text-body-lg)', color: 'var(--fg-secondary)', maxWidth: 520, margin: '0 auto var(--space-8)' }}>
          Financial clarity, marketing strategy, and business intelligence for restaurant owners — powered by AI that reads your numbers so you don't have to.
        </p>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <Button size="lg">Get started free</Button>
          <Button variant="secondary" size="lg">Watch a 2-min demo</Button>
        </div>
      </section>

      <section style={{ maxWidth: 1040, margin: '0 auto', padding: '0 var(--space-6) var(--space-24)' }}>
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-xl)', boxShadow: 'var(--shadow-lg)', padding: 'var(--space-4)' }}>
          <div style={{ background: 'var(--neutral-50)', borderRadius: 'var(--radius-lg)', height: 380, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fg-tertiary)', fontSize: '0.8125rem', border: '1px dashed var(--border-default)' }}>
            Product screenshot placeholder — dashboard view
          </div>
        </div>
      </section>

      <section style={{ maxWidth: 1040, margin: '0 auto', padding: '0 var(--space-6) var(--space-24)', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--space-8)' }}>
        {[
          { icon: 'trending-up', title: 'Financial clarity', body: 'Real-time margins, food cost, and labor — explained in plain language, not spreadsheets.' },
          { icon: 'sparkles', title: 'AI copilot', body: 'Ask questions about your business in plain English and get grounded, specific answers.' },
          { icon: 'pie-chart', title: 'Business intelligence', body: 'Know which vendors, dayparts, and menu items actually drive profit.' },
        ].map(f => (
          <div key={f.title}>
            <div style={{ width: 40, height: 40, borderRadius: 'var(--radius-md)', background: 'var(--primary-50)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 'var(--space-4)' }}>
              <Icon name={f.icon} size={20} color="var(--primary-600)" />
            </div>
            <div style={{ fontWeight: 600, fontSize: '1rem', marginBottom: 6 }}>{f.title}</div>
            <div style={{ fontSize: '0.875rem', color: 'var(--fg-secondary)', lineHeight: 1.55 }}>{f.body}</div>
          </div>
        ))}
      </section>

      <section style={{ background: 'var(--neutral-900)', color: 'var(--neutral-0)', padding: 'var(--space-24) var(--space-6)', textAlign: 'center' }}>
        <div style={{ font: 'var(--text-editorial-lg)', fontStyle: 'italic', maxWidth: 620, margin: '0 auto var(--space-4)' }}>
          "JaraLab told us our produce vendor was quietly eating 2 points of margin. We caught it in week one."
        </div>
        <div style={{ fontSize: '0.8125rem', color: 'var(--neutral-400)' }}>Owner, independent restaurant group</div>
      </section>

      <footer style={{ padding: 'var(--space-10) var(--space-8)', display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', color: 'var(--fg-tertiary)' }}>
        <div>© 2026 JaraLab</div>
        <div style={{ display: 'flex', gap: 24 }}><span>Privacy</span><span>Terms</span><span>Contact</span></div>
      </footer>
    </div>
  );
}
window.MarketingHome = MarketingHome;
