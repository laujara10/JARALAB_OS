function Topbar({ title, range, onRangeChange }) {
  const { Select, IconButton, Icon } = window.JaraLabDesignSystem_424ac8;
  return (
    <div style={{
      height: 60, flex: '0 0 auto', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center',
      justifyContent: 'space-between', padding: '0 var(--space-6)', background: 'oklch(0.995 0.002 80 / 0.85)', backdropFilter: 'blur(8px)',
    }}>
      <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: '1.0625rem', color: 'var(--fg-primary)' }}>{title}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ width: 160 }}>
          <Select value={range} onChange={e => onRangeChange(e.target.value)} options={[
            { label: 'Last 7 days', value: '7d' }, { label: 'Last 30 days', value: '30d' }, { label: 'This quarter', value: 'q' },
          ]} />
        </div>
        <IconButton name="bell" label="Notifications" />
        <IconButton name="settings" label="Settings" />
      </div>
    </div>
  );
}
window.Topbar = Topbar;
