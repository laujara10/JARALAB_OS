# Dashboard UI kit

Recreation of JaraLab's core financial-clarity / business-intelligence dashboard — the primary surface for "financial clarity" and "business intelligence" from the brief. No source codebase/Figma was attached; this is a first-pass interpretation built from the token foundations, not a pixel copy of an existing screen.

`index.html` is click-through: sidebar nav switches the top-bar title, the date-range `Select` in the top bar is live. Content composes `StatCard`, `Sparkline`, `Table`, `Badge`, `Tabs` from `components/`.

Files: `Sidebar.part.js`, `Topbar.part.js`, `DashboardScreen.part.js`, `index.html`.
