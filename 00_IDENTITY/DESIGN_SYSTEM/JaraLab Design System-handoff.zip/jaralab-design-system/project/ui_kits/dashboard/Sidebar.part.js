const NAV = [
  { key: 'overview', label: 'Overview', icon: 'layout-grid' },
  { key: 'revenue', label: 'Revenue', icon: 'trending-up' },
  { key: 'costs', label: 'Costs', icon: 'receipt' },
  { key: 'labor', label: 'Labor', icon: 'users' },
  { key: 'reports', label: 'Reports', icon: 'file-text' },
  { key: 'copilot', label: 'AI Copilot', icon: 'sparkles' },
];

function Sidebar({ active, onSelect }) {
  const { Icon } = window.JaraLabDesignSystem_424ac8;
  return (
    <div style={{ width: 220, flex: '0 0 auto', borderRight: '1px solid var(--border-subtle)', background: 'var(--bg-surface)', display: 'flex', flexDirection: 'column', padding: 'var(--space-5) var(--space-3)' }}>
      <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 18, letterSpacing: 'var(--tracking-tight)', color: 'var(--fg-primary)', padding: '0 var(--space-2)', marginBottom: 'var(--space-6)' }}>JaraLab</div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV.map(n => {
          const isActive = n.key === active;
          return (
            <button key={n.key} onClick={() => onSelect(n.key)} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', border: 'none', borderRadius: 'var(--radius-sm)',
              background: isActive ? 'var(--primary-50)' : 'transparent', color: isActive ? 'var(--primary-700)' : 'var(--fg-secondary)',
              fontFamily: 'var(--font-sans)', fontSize: '0.8125rem', fontWeight: 500, cursor: 'pointer', textAlign: 'left',
            }}>
              <Icon name={n.icon} size={16} color={isActive ? 'var(--primary-700)' : 'var(--fg-tertiary)'} />
              {n.label}
            </button>
          );
        })}
      </nav>
      <div style={{ marginTop: 'auto', display: 'flex', alignItems: 'center', gap: 8, padding: '10px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-subtle)' }}>
        <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--neutral-800)', color: 'var(--neutral-0)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 600, fontFamily: 'var(--font-sans)' }}>TK</div>
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: '0.75rem' }}>
          <div style={{ fontWeight: 500, color: 'var(--fg-primary)' }}>Tino's Kitchen</div>
          <div style={{ color: 'var(--fg-tertiary)' }}>Owner</div>
        </div>
      </div>
    </div>
  );
}
window.Sidebar = Sidebar;
