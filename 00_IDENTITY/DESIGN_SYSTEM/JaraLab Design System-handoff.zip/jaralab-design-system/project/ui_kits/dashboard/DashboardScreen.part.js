const EXPENSES = [
  { name: 'Sysco', cat: 'Produce', amt: '$4,280.00', flag: null },
  { name: 'US Foods', cat: 'Dry goods', amt: '$2,910.50', flag: null },
  { name: 'Restaurant Depot', cat: 'Paper & supplies', amt: '$1,120.00', flag: null },
  { name: 'Ecolab', cat: 'Cleaning', amt: '$640.25', flag: null },
  { name: 'Local Farms Co-op', cat: 'Produce', amt: '$6,120.00', flag: 'over' },
];

function DashboardScreen({ section }) {
  const { StatCard, Sparkline, Table, Badge, Tabs, Icon } = window.JaraLabDesignSystem_424ac8;
  const [tab, setTab] = React.useState('overview');
  const rows = EXPENSES.map(e => ({
    name: e.name, cat: <Badge tone="neutral">{e.cat}</Badge>, amt: e.amt,
    status: e.flag === 'over' ? <Badge tone="warning" dot>Over budget</Badge> : <Badge tone="success" dot>On track</Badge>,
  }));

  return (
    <div style={{ padding: 'var(--space-8) var(--space-6)', display: 'flex', flexDirection: 'column', gap: 'var(--space-6)', maxWidth: 1100 }}>
      <div>
        <div style={{ fontFamily: 'var(--font-serif)', fontSize: '1.75rem', fontStyle: 'italic', color: 'var(--fg-primary)', marginBottom: 4 }}>
          "Your food cost is up 3.2% this week. Produce is the driver."
        </div>
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: '0.8125rem', color: 'var(--fg-tertiary)' }}>JaraLab AI · generated from this week's invoices</div>
      </div>

      <Tabs tabs={[{ label: 'Overview', value: 'overview' }, { label: 'Revenue', value: 'revenue' }, { label: 'Costs', value: 'costs' }, { label: 'Labor', value: 'labor' }]} value={tab} onChange={setTab} />

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 'var(--space-4)' }}>
        <StatCard label="Revenue" value="$84,210" delta="+4.8%" deltaTone="success" caption="vs. last month" />
        <StatCard label="Food cost %" value="28.4%" delta="+1.1pt" deltaTone="danger" caption="vs. last month" />
        <StatCard label="Labor %" value="31.2%" delta="-0.4pt" deltaTone="success" caption="vs. last month" />
        <StatCard label="Net margin" value="14.6%" delta="+0.6pt" deltaTone="success" caption="vs. last month" />
      </div>

      <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: 'var(--space-6)', boxShadow: 'var(--shadow-xs)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 'var(--space-4)' }}>
          <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: '0.9375rem', color: 'var(--fg-primary)' }}>Revenue, last 8 weeks</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8125rem', color: 'var(--fg-secondary)' }}>$84,210 <span style={{ color: 'oklch(0.42 0.11 152)' }}>+4.8%</span></div>
        </div>
        <Sparkline data={[62000, 68000, 65000, 71000, 76000, 74000, 80000, 84210]} width={1000} height={90} responsive />
      </div>

      <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: 'var(--space-6)', boxShadow: 'var(--shadow-xs)' }}>
        <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: '0.9375rem', color: 'var(--fg-primary)', marginBottom: 'var(--space-3)' }}>Vendor expenses this week</div>
        <Table columns={[{ key: 'name', label: 'Vendor' }, { key: 'cat', label: 'Category' }, { key: 'amt', label: 'Amount', align: 'right', mono: true }, { key: 'status', label: 'Status', align: 'right' }]} rows={rows} />
      </div>
    </div>
  );
}
window.DashboardScreen = DashboardScreen;
