const SUGGESTIONS = [
  'Why did food cost go up this week?',
  'Summarize this month vs last month',
  'Which vendor is over budget?',
];

const SEED_MESSAGES = [
  { role: 'assistant', text: "I'm your JaraLab copilot. Ask me about revenue, costs, labor, or vendors — I read straight from your POS and invoices." },
];

function CopilotScreen() {
  const { IconButton, Icon, Badge } = window.JaraLabDesignSystem_424ac8;
  const [messages, setMessages] = React.useState(SEED_MESSAGES);
  const [input, setInput] = React.useState('');
  const scrollRef = React.useRef(null);

  const send = (text) => {
    const t = (text ?? input).trim();
    if (!t) return;
    setMessages(m => [...m, { role: 'user', text: t }]);
    setInput('');
    setTimeout(() => {
      setMessages(m => [...m, {
        role: 'assistant',
        text: 'Food cost is up 3.2% this week ($2,140). Local Farms Co-op invoices rose 8% month over month — that vendor alone is $840 over its typical weekly spend.',
        stat: { label: 'Food cost', value: '28.4%', delta: '+1.1pt' },
      }]);
    }, 500);
  };

  React.useEffect(() => { scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight); }, [messages]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', padding: 'var(--space-8) var(--space-6)', display: 'flex', flexDirection: 'column', gap: 'var(--space-5)', maxWidth: 720, margin: '0 auto', width: '100%' }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', flexDirection: m.role === 'user' ? 'row-reverse' : 'row' }}>
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flex: '0 0 auto', display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: m.role === 'user' ? 'var(--neutral-800)' : 'var(--primary-600)', color: 'var(--neutral-0)',
            }}>
              <Icon name={m.role === 'user' ? 'user' : 'sparkles'} size={14} color="white" />
            </div>
            <div style={{ maxWidth: 520 }}>
              <div style={{
                background: m.role === 'user' ? 'var(--neutral-900)' : 'var(--bg-surface)',
                color: m.role === 'user' ? 'var(--neutral-0)' : 'var(--fg-primary)',
                border: m.role === 'user' ? 'none' : '1px solid var(--border-subtle)',
                borderRadius: 'var(--radius-lg)', padding: '12px 16px', fontFamily: 'var(--font-sans)', fontSize: '0.875rem', lineHeight: 1.55,
              }}>{m.text}</div>
              {m.stat && (
                <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                  <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: '8px 12px' }}>
                    <div style={{ fontSize: '0.6875rem', color: 'var(--fg-tertiary)', marginBottom: 2 }}>{m.stat.label}</div>
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1rem', fontWeight: 600 }}>{m.stat.value} <span style={{ fontSize: '0.75rem', color: 'oklch(0.48 0.18 25)' }}>{m.stat.delta}</span></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
        {messages.length === 1 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 8 }}>
            {SUGGESTIONS.map(s => (
              <button key={s} onClick={() => send(s)} style={{
                textAlign: 'left', padding: '10px 14px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-default)',
                background: 'var(--bg-surface)', fontFamily: 'var(--font-sans)', fontSize: '0.8125rem', color: 'var(--fg-secondary)', cursor: 'pointer',
              }}>{s}</button>
            ))}
          </div>
        )}
      </div>
      <div style={{ borderTop: '1px solid var(--border-subtle)', padding: 'var(--space-4) var(--space-6)' }}>
        <div style={{ maxWidth: 720, margin: '0 auto', display: 'flex', alignItems: 'center', gap: 8, border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', padding: '8px 8px 8px 16px', background: 'var(--bg-surface)' }}>
          <input
            value={input} onChange={e => setInput(e.target.value)} placeholder="Ask about your numbers…"
            onKeyDown={e => e.key === 'Enter' && send()}
            style={{ flex: 1, border: 'none', outline: 'none', fontFamily: 'var(--font-sans)', fontSize: '0.875rem', background: 'transparent' }}
          />
          <IconButton name="send" label="Send" variant="solid" onClick={() => send()} />
        </div>
      </div>
    </div>
  );
}
window.CopilotScreen = CopilotScreen;
