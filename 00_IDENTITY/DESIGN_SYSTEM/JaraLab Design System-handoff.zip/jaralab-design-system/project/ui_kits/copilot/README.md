# AI Copilot UI kit

Recreation of JaraLab's conversational "AI-powered workflows" surface. No source was attached — first-pass interpretation from the brief's principles (calm, precise, data-grounded answers with an inline stat card, never vague).

`index.html` is click-through: type a question or click a suggestion chip, get a canned assistant reply with an inline stat callout, matching the brief's voice ("Your food cost is up 3.2% this week. Produce is the driver.").

Files: `CopilotScreen.part.js`, `index.html`.
