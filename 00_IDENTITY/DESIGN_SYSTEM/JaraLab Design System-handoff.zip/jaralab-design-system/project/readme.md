# JaraLab Design System

## Company context

JaraLab is an AI-native restaurant intelligence company. It helps restaurant owners make better business decisions through financial clarity, marketing strategy, business intelligence, and AI-powered workflows. The design language should read as confident, intelligent, simple, and premium — editorial and data-driven rather than decorative, avoiding "SaaS marketing" clichés.

**Sources.** No codebase, Figma file, deck, or existing brand assets were attached for this build — this design system was authored from the brand brief only (company description + visual-language references: premium editorial design, Apple, Linear, Stripe, Notion, Vercel). If a codebase, Figma link, or brand deck exists, attach it via the Import menu and this system should be revised against it as ground truth — see Caveats at the bottom.

**Products this system anticipates**, per the brief: dashboards, an AI copilot, financial tools, presentations, a marketing website, mobile apps, social assets, reports, internal ops tooling. This first pass builds token foundations, a core component set, and three illustrative UI kits (Dashboard/BI, AI Copilot, Marketing site) — enough surface to validate the visual system before it's pushed further into every product line.

## Content fundamentals

- **Voice**: plain-spoken, confident, precise. Short declarative sentences. No hype adjectives ("revolutionary", "game-changing"), no exclamation points.
- **Address**: second person ("you", "your restaurant") in product copy; first person plural ("we") only in company-voice contexts (about, emails). Never third person about the user.
- **Casing**: sentence case everywhere — headlines, buttons, nav labels, table headers. Avoid Title Case and avoid ALL CAPS except for small kicker/eyebrow labels (tracked-out, tiny, used sparingly).
- **Numbers**: never rounded or vague — real, specific figures with units ("$4,280 saved this month", not "save big"). Currency and percentages are core content, not decoration; align them, use tabular/mono figures.
- **Emoji**: none in product UI. None in marketing copy. This is a finance-adjacent, trust-first product — emoji undercut authority.
- **Tone examples** (style, not verbatim brand copy — none was provided):
  - Good: "Your food cost is up 3.2% this week. Produce is the driver."
  - Avoid: "🚀 Your restaurant's numbers are AMAZING this week!!"
  - Good button label: "Review the numbers" / "Send to accountant"
  - Avoid: "Unlock Your Insights Now!"
- **Errors/empty states**: matter-of-fact, never apologetic or cute. State what happened and the next action.

## Visual foundations

- **Color**: neutral, warm-tinted paper background (`--bg-page`) with near-black ink text — never pure `#000`/`#fff`. One confident primary accent, a deep forest green (`--accent-primary`) standing for clarity/growth/trust, used sparingly for primary actions, links, active states, and key data. A muted gold (`--accent-gold`) is the secondary/premium accent — used for highlights, premium tier badges, and editorial emphasis, never as a second primary button color. Semantic colors (success/warning/danger/info) are distinct from the brand accents so status is never ambiguous with brand color.
- **Backgrounds**: flat, no gradients, no textures or patterns. No hand-drawn illustration language — this is a data/finance product, imagery should be photographic (real restaurant/food photography, warm and naturalistic, not stock-glossy) used full-bleed only in marketing/hero contexts, never inside dashboards.
- **Type**: strong, editorial hierarchy. Geist (sans) carries all UI, body copy, and display headlines. Newsreader (serif) is reserved for editorial moments only — large pull quotes, big single stat callouts, section dividers in reports/decks — never for UI chrome or buttons. Geist Mono is used for all financial figures, timestamps, and code so digits align and read as data.
- **Spacing**: generous. An 8/4px-derived scale (`--space-*`) with dashboard density trending toward `--space-4`–`--space-6` between elements and `--space-8`+ between sections. Whitespace is a primary design tool, not a gap to fill.
- **Corner radii**: small and consistent — `--radius-sm` (6px) for controls/inputs, `--radius-md` (10px) for cards, `--radius-lg`/`--radius-xl` for large surfaces/modals, `--radius-full` for pills/avatars. Never sharp 0px corners on interactive elements, never oversized "bubbly" 24px+ radii on small controls.
- **Cards**: flat `--bg-surface` fill, 1px `--border-subtle` hairline, `--shadow-xs`/`--shadow-sm` at rest (barely-there), `--shadow-md` on hover/elevated states. No colored left-border accent bars — that pattern is explicitly avoided.
- **Shadows**: soft, low-opacity, warm-neutral tinted (never pure black). Elevation communicates hierarchy (resting card vs. modal vs. dropdown) rather than decoration.
- **Borders**: hairline (1px) `--border-subtle`/`--border-default` throughout; a slightly stronger `--border-strong` for inputs on focus-adjacent states; `--border-accent` only for active/selected states.
- **Hover states**: subtle — background shifts one step darker/lighter on the neutral ramp (e.g. `--neutral-50` → `--neutral-100`), or the accent shifts to `--accent-primary-hover` (one step deeper). No scale/bounce on hover.
- **Press/active states**: one step further on the same ramp (`--accent-primary-active`), plus a very slight (~1px) translate or opacity dip — no springy bounce, no shrink-then-grow.
- **Focus states**: a visible `--shadow-focus` ring (3px, brand-tinted, low opacity) on all interactive elements — accessibility-first, never removed.
- **Animation**: minimal and purposeful. Standard `--ease-standard`/`--ease-out` cubic-beziers, `--duration-fast` (120ms) for micro-interactions (hover, toggle), `--duration-standard` (200ms) for panel/dialog transitions. Fades and gentle slide/scale-in only — no bounce, no elastic easing, no infinite decorative loops.
- **Transparency & blur**: used narrowly — a translucent, blurred surface (`backdrop-filter: blur(...)`) for sticky headers/toolbars and modal scrims only. Never for cards or body content.
- **Imagery color vibe**: warm, natural, editorial food/restaurant photography when used — not saturated "foodie" oversaturation, not black & white. No imagery inside data-dense dashboard screens; imagery lives in marketing/report/deck contexts.
- **Layout rules**: dashboards are grid-based with a fixed left sidebar and sticky top bar; content area scrolls independently. Marketing/editorial layouts use a constrained reading-width column for text with full-bleed breakouts for imagery/stats only.

## Iconography

No icon font, sprite sheet, or custom icon set was provided with the brief. **Substitution**: this system links [Lucide](https://lucide.dev) icons from CDN (`lucide-static` via unpkg) as the closest match to the intended aesthetic — geometric, single-weight (1.5–2px stroke), no fill, rounded joins — consistent with the Apple/Linear/Stripe/Vercel reference points. This is flagged as a substitution; if JaraLab has its own icon set, attach it and this system should switch to it. No emoji or Unicode glyphs are used as icons. Icons appear at 16/20/24px, inherit `currentColor`, and never carry a background chip except inside `IconButton`.

## Assets

No logo file was provided. **No logo has been fabricated.** Wherever a mark would appear, the wordmark is rendered in plain type: "JaraLab" in `--font-sans` 600 weight, sentence case. See `assets/README.md`. If a real logo exists, attach it and this note should be replaced.

## Intentional additions

- **Icon** wrapper component: no source defines one, but a thin wrapper around the Lucide substitution set is needed for consistent sizing/color across the kit.
- Standard component set (Button, Input, Select, Checkbox, Radio, Switch, Card, Badge, Tag, Tabs, Dialog, Toast, Tooltip, plus data-display primitives StatCard, Table, Sparkline) was authored from scratch per the brief's principles, since no source defined a concrete inventory.

## Index

- `styles.css` — root stylesheet, imports every token file. Link this one file.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css` (also holds radius/shadow/motion), `fonts.css` (webfont import + font-family vars).
- `components/` — reusable primitives, grouped by concern:
  - `components/core/` — Button, IconButton, Icon, Badge, Tag, Card
  - `components/forms/` — Input, Select, Checkbox, Radio, Switch
  - `components/navigation/` — Tabs
  - `components/feedback/` — Dialog, Toast, Tooltip
  - `components/data/` — StatCard, Table, Sparkline
- `ui_kits/` — full-screen click-through recreations:
  - `ui_kits/dashboard/` — financial clarity / BI dashboard
  - `ui_kits/copilot/` — AI copilot chat interface
  - `ui_kits/marketing/` — marketing homepage
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand groups in the Design System tab).
- `assets/` — icons (Lucide, CDN-linked, see `assets/README.md`), no logo/imagery provided.
- `SKILL.md` — portable skill definition for use in Claude Code or other agent environments.

## Caveats — please read

- **No source materials were attached** (no codebase, no Figma, no deck, no brand assets). Everything here — palette, type pairing, component shapes, copy voice — is a first-pass interpretation of the written brief, not a recreation of an existing product. Treat this as v0.
- **Fonts are a substitution**: Geist (sans/mono) + Newsreader (serif), loaded from Google Fonts CDN. If JaraLab has licensed/brand fonts, attach the font files and this system should be rebuilt on them.
- **Icons are a substitution**: Lucide, CDN-linked. If JaraLab has its own icon set, attach it.
- **No logo**: plain wordmark used everywhere a mark would go.
- **Ask**: please attach any of — a Figma file/link, a live codebase, a pitch deck, brand guidelines, or product screenshots — so this system can be corrected against ground truth rather than invented. In the meantime, tell me what to iterate on: color direction, type pairing, component density, or the three UI kit surfaces chosen.
