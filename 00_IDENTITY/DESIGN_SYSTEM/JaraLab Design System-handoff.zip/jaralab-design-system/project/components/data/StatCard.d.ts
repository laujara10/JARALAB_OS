import React from 'react';
/**
 * StatCard — a single labeled metric with mono-figure value and delta, the base unit of every dashboard.
 * @startingPoint section="Data" subtitle="Single metric + delta" viewport="220x160"
 */
export interface StatCardProps {
  label: string;
  /** Formatted value string, e.g. "$18,240" or "28.4%" — pre-formatted by the caller. */
  value: string;
  /** Formatted delta string, e.g. "+3.2%" or "-$412" */
  delta?: string;
  deltaTone?: 'success' | 'danger' | 'neutral';
  caption?: string;
}
