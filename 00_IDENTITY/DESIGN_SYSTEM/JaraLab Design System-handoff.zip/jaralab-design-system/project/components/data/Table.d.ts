import React from 'react';
/**
 * Table — data grid with uppercase tracked-out headers and hairline row dividers.
 * @startingPoint section="Data" subtitle="Data grid, mono numeric columns" viewport="600x260"
 */
export interface TableColumn { key: string; label: string; align?: 'left' | 'right' | 'center'; mono?: boolean; }
export interface TableProps {
  columns: TableColumn[];
  /** Array of row objects keyed by column `key`. Cell content can be any ReactNode (e.g. a Badge). */
  rows: Record<string, React.ReactNode>[];
}
