Data grid — expense lists, vendor tables, report line items. Headers are small, uppercase, tracked-out; rows are hairline-divided, no zebra striping.

```jsx
<Table columns={[{key:'name',label:'Vendor'},{key:'amt',label:'Amount',align:'right',mono:true}]} rows={[{name:'Sysco',amt:'$4,280.00'}]} />
```

Set `mono` on numeric/currency columns so figures align on tabular digits.
