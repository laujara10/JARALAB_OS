import React from 'react';

export function Table({ columns = [], rows = [] }) {
  return (
    <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: 'var(--font-sans)' }}>
      <thead>
        <tr>
          {columns.map(c => (
            <th key={c.key} style={{
              textAlign: c.align || 'left', padding: '8px 12px', fontSize: '0.6875rem', fontWeight: 500,
              color: 'var(--fg-tertiary)', textTransform: 'uppercase', letterSpacing: 'var(--tracking-wide)',
              borderBottom: '1px solid var(--border-default)',
            }}>{c.label}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
            {columns.map(c => (
              <td key={c.key} style={{
                textAlign: c.align || 'left', padding: '10px 12px', fontSize: '0.8125rem', color: 'var(--fg-primary)',
                fontFamily: c.mono ? 'var(--font-mono)' : 'inherit', fontVariantNumeric: c.mono ? 'tabular-nums' : 'normal',
              }}>{r[c.key]}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
