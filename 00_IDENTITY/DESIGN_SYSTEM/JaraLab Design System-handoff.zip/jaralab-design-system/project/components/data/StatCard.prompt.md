The atomic unit of every dashboard/report — a labeled metric in mono figures with a colored delta.

```jsx
<StatCard label="Food cost" value="28.4%" delta="+1.1pt" deltaTone="danger" caption="vs. last month" />
```

Never round the value for display — pass the real formatted figure. `deltaTone` colors the delta only (green=good, red=bad), independent of sign — a cost going down is `success` even though the number itself is negative.
