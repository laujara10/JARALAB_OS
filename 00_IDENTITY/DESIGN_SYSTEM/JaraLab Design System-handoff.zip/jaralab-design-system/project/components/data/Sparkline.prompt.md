Minimal trend line with no axes/labels — table rows, stat card footers, compact trend indicators.

```jsx
<Sparkline data={[12,14,11,18,22,20,26]} color="var(--accent-primary)" />
```

Use `color="var(--danger-500)"` for a declining/negative metric. Pass `responsive` to fill the container's width (e.g. a full-width dashboard card) instead of a fixed pixel size.
