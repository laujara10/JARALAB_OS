import React from 'react';
/**
 * Sparkline — minimal inline trend line, no axes/labels — for table cells and stat cards.
 * @startingPoint section="Data" subtitle="Inline trend line" viewport="200x100"
 */
export interface SparklineProps {
  data: number[];
  /** Coordinate-space width used for point spacing (and rendered px width unless responsive). Default 120. */
  width?: number;
  height?: number;
  color?: string;
  /** Fill the area under the line at 12% opacity. Default true. */
  fill?: boolean;
  /** Render at 100% of the container's width (viewBox scales) instead of a fixed pixel width. Default false. */
  responsive?: boolean;
}
