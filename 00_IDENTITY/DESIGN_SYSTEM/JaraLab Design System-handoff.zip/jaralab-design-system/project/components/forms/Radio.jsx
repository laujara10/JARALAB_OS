import React from 'react';

export function Radio({ label, checked = false, onChange, name, disabled = false }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, cursor: disabled ? 'not-allowed' : 'pointer', fontFamily: 'var(--font-sans)', opacity: disabled ? 0.5 : 1 }}>
      <span style={{
        width: 18, height: 18, borderRadius: '50%', flex: '0 0 auto',
        border: `1px solid ${checked ? 'var(--accent-primary)' : 'var(--border-strong)'}`,
        background: 'var(--bg-surface)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {checked && <span style={{ width: 9, height: 9, borderRadius: '50%', background: 'var(--accent-primary)' }} />}
      </span>
      <input type="radio" name={name} checked={checked} disabled={disabled} onChange={onChange} style={{ display: 'none' }} />
      {label && <span style={{ fontSize: '0.875rem', color: 'var(--fg-primary)' }}>{label}</span>}
    </label>
  );
}
