import React from 'react';

export function Switch({ checked = false, onChange, disabled = false, label }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1, fontFamily: 'var(--font-sans)' }}>
      <span style={{
        width: 36, height: 21, borderRadius: 'var(--radius-full)', padding: 2, display: 'flex',
        background: checked ? 'var(--accent-primary)' : 'var(--neutral-200)',
        transition: 'background var(--duration-standard) var(--ease-standard)',
      }}>
        <span style={{
          width: 17, height: 17, borderRadius: '50%', background: 'white',
          boxShadow: 'var(--shadow-sm)', transform: checked ? 'translateX(15px)' : 'translateX(0)',
          transition: 'transform var(--duration-standard) var(--ease-out)',
        }} />
      </span>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={onChange} style={{ display: 'none' }} />
      {label && <span style={{ fontSize: '0.875rem', color: 'var(--fg-primary)' }}>{label}</span>}
    </label>
  );
}
