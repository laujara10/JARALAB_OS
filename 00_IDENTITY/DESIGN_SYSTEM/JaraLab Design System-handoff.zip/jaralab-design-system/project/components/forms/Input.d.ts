import React from 'react';
/**
 * Input — single-line text field with label, optional leading icon, error state.
 * @startingPoint section="Forms" subtitle="Text field, label + error state" viewport="360x120"
 */
export interface InputProps {
  label?: string;
  placeholder?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;
  /** Error message — shows red border + helper text below. */
  error?: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  size?: 'sm' | 'md';
}
