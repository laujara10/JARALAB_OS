Checkbox for multi-select lists, settings toggles, table row selection.

```jsx
<Checkbox label="Include tax" checked={v} onChange={e=>setV(e.target.checked)} />
```
