On/off toggle — settings screens, notification preferences.

```jsx
<Switch label="Email weekly summary" checked={v} onChange={e=>setV(e.target.checked)} />
```
