import React from 'react';

export function Checkbox({ label, checked = false, onChange, disabled = false }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, cursor: disabled ? 'not-allowed' : 'pointer', fontFamily: 'var(--font-sans)', opacity: disabled ? 0.5 : 1 }}>
      <span style={{
        width: 18, height: 18, borderRadius: 5, flex: '0 0 auto',
        border: `1px solid ${checked ? 'var(--accent-primary)' : 'var(--border-strong)'}`,
        background: checked ? 'var(--accent-primary)' : 'var(--bg-surface)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all var(--duration-fast) var(--ease-standard)',
      }}>
        {checked && <svg width="11" height="9" viewBox="0 0 11 9" fill="none"><path d="M1 4.5L4 7.5L10 1" stroke="white" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>}
      </span>
      <input type="checkbox" checked={checked} disabled={disabled} onChange={onChange} style={{ display: 'none' }} />
      {label && <span style={{ fontSize: '0.875rem', color: 'var(--fg-primary)' }}>{label}</span>}
    </label>
  );
}
