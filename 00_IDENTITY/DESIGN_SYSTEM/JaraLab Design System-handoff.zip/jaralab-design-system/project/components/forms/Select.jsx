import React from 'react';

export function Select({ label, value, onChange, options = [], disabled = false }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' }}>
      {label && <span style={{ fontSize: '0.8125rem', fontWeight: 500, color: 'var(--fg-primary)' }}>{label}</span>}
      <div style={{
        position: 'relative', height: 38, borderRadius: 'var(--radius-sm)',
        background: disabled ? 'var(--neutral-50)' : 'var(--bg-surface)',
        border: `1px solid ${focus ? 'var(--border-strong)' : 'var(--border-default)'}`,
        boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      }}>
        <select
          value={value} disabled={disabled} onChange={onChange}
          onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{
            width: '100%', height: '100%', border: 'none', outline: 'none', background: 'transparent',
            padding: '0 32px 0 var(--space-3)', fontSize: '0.875rem', color: 'var(--fg-primary)',
            fontFamily: 'inherit', appearance: 'none', cursor: disabled ? 'not-allowed' : 'pointer',
          }}
        >
          {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <span style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: 'var(--fg-tertiary)', fontSize: 10 }}>▾</span>
      </div>
    </label>
  );
}
