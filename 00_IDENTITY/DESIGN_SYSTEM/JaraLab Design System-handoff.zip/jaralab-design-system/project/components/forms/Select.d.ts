import React from 'react';
/**
 * Select — native dropdown, styled to match Input.
 * @startingPoint section="Forms" subtitle="Dropdown select" viewport="360x100"
 */
export interface SelectOption { label: string; value: string; }
export interface SelectProps {
  label?: string;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: SelectOption[];
  disabled?: boolean;
}
