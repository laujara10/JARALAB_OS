Single-line text input — forms, filters, search bars.

```jsx
<Input label="Restaurant name" placeholder="e.g. Tino's Kitchen" value={v} onChange={e=>setV(e.target.value)} />
```

Pass `icon={<Icon name="search" size={16} color="var(--fg-tertiary)"/>}` for a leading icon. `error` shows a red border + helper line below — don't also show a separate toast for the same validation.
