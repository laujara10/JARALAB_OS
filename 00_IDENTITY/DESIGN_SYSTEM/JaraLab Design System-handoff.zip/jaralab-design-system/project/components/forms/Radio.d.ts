import React from 'react';
/**
 * Radio — single-select control, brand-green dot when checked.
 * @startingPoint section="Forms" subtitle="Radio button group" viewport="280x100"
 */
export interface RadioProps {
  label?: string;
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  name?: string;
  disabled?: boolean;
}
