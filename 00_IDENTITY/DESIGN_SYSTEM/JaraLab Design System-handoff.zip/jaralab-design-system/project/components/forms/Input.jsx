import React from 'react';

export function Input({ label, placeholder, value, onChange, type = 'text', error, icon, disabled = false, size = 'md' }) {
  const [focus, setFocus] = React.useState(false);
  const h = size === 'sm' ? 32 : 38;
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' }}>
      {label && <span style={{ fontSize: '0.8125rem', fontWeight: 500, color: 'var(--fg-primary)' }}>{label}</span>}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, height: h,
        padding: '0 var(--space-3)', borderRadius: 'var(--radius-sm)',
        background: disabled ? 'var(--neutral-50)' : 'var(--bg-surface)',
        border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--border-strong)' : 'var(--border-default)'}`,
        boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
        transition: 'box-shadow var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)',
      }}>
        {icon}
        <input
          type={type} value={value} placeholder={placeholder} disabled={disabled}
          onChange={onChange} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          style={{ border: 'none', outline: 'none', background: 'transparent', flex: 1, fontSize: '0.875rem', color: 'var(--fg-primary)', fontFamily: 'inherit' }}
        />
      </div>
      {error && <span style={{ fontSize: '0.75rem', color: 'var(--danger-500)' }}>{error}</span>}
    </label>
  );
}
