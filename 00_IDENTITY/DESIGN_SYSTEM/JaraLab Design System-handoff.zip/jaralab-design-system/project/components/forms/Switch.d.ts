import React from 'react';
/**
 * Switch — on/off toggle for settings and preferences.
 * @startingPoint section="Forms" subtitle="Toggle switch" viewport="280x100"
 */
export interface SwitchProps {
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
  label?: string;
}
