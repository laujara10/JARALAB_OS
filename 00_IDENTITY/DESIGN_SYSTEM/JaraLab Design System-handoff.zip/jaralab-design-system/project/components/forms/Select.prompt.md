Native `<select>` styled to match `Input` — period/location/report-range pickers.

```jsx
<Select label="Time range" value={v} onChange={e=>setV(e.target.value)} options={[{label:'Last 7 days',value:'7d'},{label:'Last 30 days',value:'30d'}]} />
```
