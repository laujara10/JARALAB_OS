Radio for mutually-exclusive choices (report type, plan tier).

```jsx
<Radio name="range" label="This month" checked={v==='month'} onChange={()=>setV('month')} />
```
