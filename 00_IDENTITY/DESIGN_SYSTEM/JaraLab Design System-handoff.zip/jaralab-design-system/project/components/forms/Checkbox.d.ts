import React from 'react';
/**
 * Checkbox — custom-drawn box, brand-green when checked.
 * @startingPoint section="Forms" subtitle="Checkbox, checked/unchecked/disabled" viewport="280x100"
 */
export interface CheckboxProps {
  label?: string;
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
}
