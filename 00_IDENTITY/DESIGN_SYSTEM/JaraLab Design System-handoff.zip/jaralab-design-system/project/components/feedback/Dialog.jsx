import React from 'react';

export function Dialog({ open, title, children, onClose, actions }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'absolute', inset: 0, background: 'oklch(0.2 0.02 55 / 0.4)',
      backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50,
    }}>
      <div style={{
        background: 'var(--bg-surface)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-lg)',
        width: 420, maxWidth: '90%', padding: 'var(--space-6)', fontFamily: 'var(--font-sans)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ fontSize: '1.0625rem', fontWeight: 600, color: 'var(--fg-primary)' }}>{title}</div>
          {onClose && <button onClick={onClose} aria-label="Close" style={{ border: 'none', background: 'transparent', color: 'var(--fg-tertiary)', cursor: 'pointer', fontSize: 18 }}>×</button>}
        </div>
        <div style={{ fontSize: '0.875rem', color: 'var(--fg-secondary)', lineHeight: 1.55 }}>{children}</div>
        {actions && <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 20 }}>{actions}</div>}
      </div>
    </div>
  );
}
