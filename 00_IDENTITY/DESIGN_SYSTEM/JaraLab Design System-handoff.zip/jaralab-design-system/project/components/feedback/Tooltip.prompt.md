Hover tooltip, dark inverse fill — pairs with icon-only controls or truncated table cells.

```jsx
<Tooltip label="Export as CSV"><IconButton name="download" label="Export"/></Tooltip>
```
