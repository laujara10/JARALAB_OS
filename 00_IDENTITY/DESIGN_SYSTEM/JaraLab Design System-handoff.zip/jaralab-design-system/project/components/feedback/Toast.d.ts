import React from 'react';
/**
 * Toast — transient inverse-dark notification, bottom-corner stack.
 * @startingPoint section="Feedback" subtitle="Transient notification" viewport="400x120"
 */
export interface ToastProps {
  tone?: 'info' | 'success' | 'warning' | 'danger';
  title: string;
  description?: string;
  onClose?: () => void;
}
