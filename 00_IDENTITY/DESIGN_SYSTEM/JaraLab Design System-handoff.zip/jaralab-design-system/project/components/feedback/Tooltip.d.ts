import React from 'react';
/**
 * Tooltip — hover-triggered label for icon buttons and truncated content.
 * @startingPoint section="Feedback" subtitle="Hover label" viewport="300x120"
 */
export interface TooltipProps {
  children: React.ReactNode;
  label: string;
  side?: 'top' | 'bottom';
}
