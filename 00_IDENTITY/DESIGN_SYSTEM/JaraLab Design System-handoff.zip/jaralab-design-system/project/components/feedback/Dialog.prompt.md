Centered modal, blurred dark scrim (one of the only places blur is used) — confirmations, focused single-task flows.

```jsx
<Dialog open={open} title="Delete report?" onClose={()=>setOpen(false)} actions={<><Button variant="ghost" onClick={close}>Cancel</Button><Button variant="danger">Delete</Button></>}>
  This can't be undone.
</Dialog>
```
