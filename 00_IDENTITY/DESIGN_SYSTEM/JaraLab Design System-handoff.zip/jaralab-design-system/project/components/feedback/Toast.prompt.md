Transient system notification — inverse dark surface, status dot, auto-dismiss. Stack bottom-right.

```jsx
<Toast tone="success" title="Report sent" description="Delivered to your accountant" onClose={()=>{}} />
```
