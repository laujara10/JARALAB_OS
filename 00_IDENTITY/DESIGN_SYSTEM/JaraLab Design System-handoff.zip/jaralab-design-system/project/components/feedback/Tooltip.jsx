import React from 'react';

export function Tooltip({ children, label, side = 'top' }) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: { bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: 6 },
    bottom: { top: '100%', left: '50%', transform: 'translateX(-50%)', marginTop: 6 },
  }[side] || {};
  return (
    <span style={{ position: 'relative', display: 'inline-flex' }} onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)}>
      {children}
      {show && (
        <span style={{
          position: 'absolute', ...pos, whiteSpace: 'nowrap', padding: '5px 9px',
          background: 'var(--neutral-900)', color: 'var(--neutral-0)', borderRadius: 'var(--radius-sm)',
          fontSize: '0.75rem', fontFamily: 'var(--font-sans)', boxShadow: 'var(--shadow-md)', zIndex: 20,
          pointerEvents: 'none',
        }}>{label}</span>
      )}
    </span>
  );
}
