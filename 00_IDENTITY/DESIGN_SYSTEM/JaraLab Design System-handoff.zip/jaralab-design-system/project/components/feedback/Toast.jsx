import React from 'react';

const tones = {
  info: { bg: 'var(--neutral-900)', icon: 'info', color: 'var(--neutral-0)' },
  success: { bg: 'var(--neutral-900)', icon: 'check-circle-2', color: 'var(--success-500)' },
  warning: { bg: 'var(--neutral-900)', icon: 'alert-triangle', color: 'var(--warning-500)' },
  danger: { bg: 'var(--neutral-900)', icon: 'alert-circle', color: 'var(--danger-500)' },
};

export function Toast({ tone = 'info', title, description, onClose }) {
  const t = tones[tone] || tones.info;
  return (
    <div style={{
      display: 'flex', alignItems: 'flex-start', gap: 10, background: t.bg, color: 'var(--neutral-0)',
      padding: 'var(--space-3) var(--space-4)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-lg)',
      minWidth: 280, maxWidth: 360, fontFamily: 'var(--font-sans)',
    }}>
      <span style={{ width: 16, height: 16, borderRadius: '50%', background: t.color, flex: '0 0 auto', marginTop: 3 }} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: '0.875rem', fontWeight: 600 }}>{title}</div>
        {description && <div style={{ fontSize: '0.8125rem', color: 'var(--neutral-300)', marginTop: 2 }}>{description}</div>}
      </div>
      {onClose && <button onClick={onClose} aria-label="Dismiss" style={{ border: 'none', background: 'transparent', color: 'var(--neutral-400)', cursor: 'pointer', fontSize: 16, lineHeight: 1, padding: 0 }}>×</button>}
    </div>
  );
}
