import React from 'react';
/**
 * Dialog — centered modal with blurred scrim, for confirmations and focused tasks.
 * @startingPoint section="Feedback" subtitle="Modal dialog, blurred scrim" viewport="500x360"
 */
export interface DialogProps {
  open: boolean;
  title: string;
  children?: React.ReactNode;
  onClose?: () => void;
  /** Footer action buttons, e.g. <><Button variant="ghost">Cancel</Button><Button>Confirm</Button></> */
  actions?: React.ReactNode;
}
