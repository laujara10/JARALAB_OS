import React from 'react';
/**
 * Button — primary interactive action. Five variants, three sizes, optional
 * leading/trailing icon slots (pass an <Icon/>), disabled state.
 * @startingPoint section="Core" subtitle="Primary action control, 5 variants" viewport="700x160"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual style. Default "primary". */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'gold';
  /** Default "md". */
  size?: 'sm' | 'md' | 'lg';
  /** Leading icon element, e.g. <Icon name="plus" size={16} /> */
  icon?: React.ReactNode;
  /** Trailing icon element */
  iconRight?: React.ReactNode;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  type?: 'button' | 'submit';
  style?: React.CSSProperties;
}
