Base surface for grouped content — dashboard panels, list rows, report sections. Flat fill, hairline border, barely-there shadow at rest (never a colored left-border accent).

```jsx
<Card padding="md" hoverable>{content}</Card>
```
