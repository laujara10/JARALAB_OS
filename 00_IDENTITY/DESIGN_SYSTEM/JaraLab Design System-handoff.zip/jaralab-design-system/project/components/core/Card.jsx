import React from 'react';

export function Card({ children, padding = 'md', hoverable = false, style = {} }) {
  const [hover, setHover] = React.useState(false);
  const pad = { sm: 'var(--space-4)', md: 'var(--space-6)', lg: 'var(--space-8)' }[padding];
  return (
    <div
      onMouseEnter={() => hoverable && setHover(true)}
      onMouseLeave={() => hoverable && setHover(false)}
      style={{
        background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-md)', padding: pad,
        boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-xs)',
        transition: 'box-shadow var(--duration-standard) var(--ease-standard)',
        ...style,
      }}
    >
      {children}
    </div>
  );
}
