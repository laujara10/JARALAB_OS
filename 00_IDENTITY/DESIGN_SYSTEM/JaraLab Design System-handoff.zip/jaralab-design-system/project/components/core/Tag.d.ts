import React from 'react';
/**
 * Tag — filter/selection chip (dismissible), distinct from Badge (status, not selectable).
 * @startingPoint section="Core" subtitle="Filter chip, selectable/removable" viewport="500x100"
 */
export interface TagProps {
  children?: React.ReactNode;
  /** Shows a remove (×) button when provided. */
  onRemove?: () => void;
  /** Selected/active visual state. Default false. */
  selected?: boolean;
}
