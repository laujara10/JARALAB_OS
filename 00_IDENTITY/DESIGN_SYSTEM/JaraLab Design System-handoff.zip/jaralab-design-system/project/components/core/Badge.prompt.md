Small status pill — table cells, list rows, card headers. Not clickable.

```jsx
<Badge tone="success" dot>On track</Badge>
```

Tones map to semantic meaning: `success`/`warning`/`danger` for status, `primary`/`gold` for brand emphasis (e.g. "New", "Pro"), `neutral` for plain categorization. Use `dot` for at-a-glance status lists.
