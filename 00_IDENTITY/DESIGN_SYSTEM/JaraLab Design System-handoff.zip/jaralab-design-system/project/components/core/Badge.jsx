import React from 'react';

const tones = {
  neutral: { bg: 'var(--neutral-100)', fg: 'var(--neutral-700)' },
  primary: { bg: 'var(--primary-50)', fg: 'var(--primary-700)' },
  success: { bg: 'var(--success-100)', fg: 'oklch(0.38 0.11 152)' },
  warning: { bg: 'var(--warning-100)', fg: 'oklch(0.45 0.13 75)' },
  danger:  { bg: 'var(--danger-100)', fg: 'oklch(0.42 0.18 25)' },
  gold:    { bg: 'var(--gold-50)', fg: 'var(--gold-700)' },
};

export function Badge({ children, tone = 'neutral', dot = false }) {
  const t = tones[tone] || tones.neutral;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '3px 9px', borderRadius: 'var(--radius-full)',
      background: t.bg, color: t.fg,
      fontFamily: 'var(--font-sans)', fontWeight: 500, fontSize: '0.75rem', lineHeight: 1.3,
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.fg }} />}
      {children}
    </span>
  );
}
