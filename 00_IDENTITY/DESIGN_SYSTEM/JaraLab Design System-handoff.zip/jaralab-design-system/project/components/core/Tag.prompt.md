Chip for filters, selected categories, and multi-select inputs — bordered, optionally removable. Different from `Badge` (which is a plain status pill, non-interactive).

```jsx
<Tag selected onRemove={() => {}}>Dinner service</Tag>
```
