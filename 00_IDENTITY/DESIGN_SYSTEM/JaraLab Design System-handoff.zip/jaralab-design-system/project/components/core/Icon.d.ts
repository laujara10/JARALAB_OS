import React from 'react';
/**
 * Icon — renders a Lucide icon (CDN-linked SVG, see assets/README.md) as a
 * currentColor-able, any-size mask so it can be recolored/sized like a glyph.
 * @startingPoint section="Core" subtitle="Lucide glyph, any color/size" viewport="240x120"
 */
export interface IconProps {
  /** Lucide icon name, e.g. "arrow-right", "trending-up" — see lucide.dev/icons */
  name: string;
  /** Pixel size (width & height). Default 20. */
  size?: number;
  /** CSS color. Default currentColor. */
  color?: string;
  className?: string;
  style?: React.CSSProperties;
}
