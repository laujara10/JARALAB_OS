import React from 'react';

export function Tag({ children, onRemove, selected = false }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '4px 10px', borderRadius: 'var(--radius-sm)',
      background: selected ? 'var(--primary-50)' : 'var(--bg-surface-2)',
      border: `1px solid ${selected ? 'var(--border-accent)' : 'var(--border-default)'}`,
      color: selected ? 'var(--primary-700)' : 'var(--fg-secondary)',
      fontFamily: 'var(--font-sans)', fontWeight: 500, fontSize: '0.8125rem',
    }}>
      {children}
      {onRemove && (
        <button
          type="button" aria-label="Remove" onClick={onRemove}
          style={{ border: 'none', background: 'transparent', cursor: 'pointer', padding: 0, display: 'flex', color: 'inherit', opacity: 0.6 }}
        >×</button>
      )}
    </span>
  );
}
