Icon-only square button — toolbars, table row actions, panel headers, chat composer controls.

```jsx
<IconButton name="more-horizontal" label="More actions" variant="ghost" />
```

`variant="ghost"` (default) for toolbars/tables; `variant="solid"` for a single emphasized icon action (e.g. send in a composer). `active` shows a persistent neutral-100 fill (selected state). Always pass `label` — it's the accessible name and hover title, there's no visible text.
