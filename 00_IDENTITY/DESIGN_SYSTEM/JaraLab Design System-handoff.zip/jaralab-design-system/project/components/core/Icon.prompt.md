Renders a single Lucide icon (CDN-linked) as a recolorable, resizable glyph — use anywhere a UI icon is needed.

```jsx
<Icon name="trending-up" size={16} color="var(--accent-primary)" />
```

Variants/props: any [Lucide](https://lucide.dev/icons) name works. `size` in px (default 20). `color` accepts any CSS color, including token vars. Pass `aria-label` to override the default (icon name) for accessibility when the icon isn't purely decorative.
