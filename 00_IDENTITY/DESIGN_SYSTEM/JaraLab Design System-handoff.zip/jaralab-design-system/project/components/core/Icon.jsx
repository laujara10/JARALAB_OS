import React from 'react';

export function Icon({ name, size = 20, color = 'currentColor', strokeWidth, className = '', style = {}, ...rest }) {
  const url = `https://unpkg.com/lucide-static@0.469.0/icons/${name}.svg`;
  return (
    <span
      role="img"
      aria-label={rest['aria-label'] || name}
      className={`jl-icon ${className}`}
      style={{
        display: 'inline-block',
        width: size,
        height: size,
        flex: '0 0 auto',
        backgroundColor: color,
        WebkitMaskImage: `url(${url})`,
        maskImage: `url(${url})`,
        WebkitMaskSize: '100% 100%',
        maskSize: '100% 100%',
        WebkitMaskRepeat: 'no-repeat',
        maskRepeat: 'no-repeat',
        ...style,
      }}
      {...rest}
    />
  );
}
