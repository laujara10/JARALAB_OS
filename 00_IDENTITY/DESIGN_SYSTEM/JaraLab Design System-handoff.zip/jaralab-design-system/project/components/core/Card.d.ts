import React from 'react';
/**
 * Card — flat surface container: hairline border, near-invisible resting shadow.
 * @startingPoint section="Core" subtitle="Base surface, hairline + soft shadow" viewport="500x200"
 */
export interface CardProps {
  children?: React.ReactNode;
  padding?: 'sm' | 'md' | 'lg';
  /** Elevate shadow on hover — use for clickable cards. Default false. */
  hoverable?: boolean;
  style?: React.CSSProperties;
}
