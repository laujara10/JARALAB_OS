The primary interactive control for any confirmable action — forms, toolbars, dialogs, empty states.

```jsx
<Button variant="primary" size="md" icon={<Icon name="plus" size={16} />}>New report</Button>
```

Variants: `primary` (brand green fill — the one confident CTA per view), `secondary` (outlined, neutral), `ghost` (borderless, for toolbars/low-emphasis actions), `danger` (destructive confirm), `gold` (rare — premium/upsell moments only, never a second primary). Sizes `sm`/`md`/`lg`. `disabled` mutes to neutral-100. Hover darkens one step on the same ramp; press adds a 1px translate — no bounce.
