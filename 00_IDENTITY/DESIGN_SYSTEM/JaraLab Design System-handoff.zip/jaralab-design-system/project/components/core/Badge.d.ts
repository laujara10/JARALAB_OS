import React from 'react';
/**
 * Badge — small pill for status/category labels (table cells, list rows, headers).
 * @startingPoint section="Core" subtitle="Status pill, 6 tones" viewport="500x100"
 */
export interface BadgeProps {
  children?: React.ReactNode;
  tone?: 'neutral' | 'primary' | 'success' | 'warning' | 'danger' | 'gold';
  /** Show a small leading dot instead of an icon. Default false. */
  dot?: boolean;
}
