import React from 'react';
/**
 * IconButton — square icon-only control for toolbars, table row actions, and headers.
 * @startingPoint section="Core" subtitle="Icon-only control, ghost/solid" viewport="360x120"
 */
export interface IconButtonProps {
  /** Lucide icon name */
  name: string;
  size?: 'sm' | 'md' | 'lg';
  variant?: 'ghost' | 'solid';
  active?: boolean;
  disabled?: boolean;
  /** Accessible label (also used as title tooltip) */
  label: string;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
