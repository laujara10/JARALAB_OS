import React from 'react';
import { Icon } from './Icon.jsx';

const sizes = { sm: 28, md: 34, lg: 40 };

export function IconButton({ name, size = 'md', variant = 'ghost', active = false, disabled = false, label, onClick, style = {} }) {
  const [hover, setHover] = React.useState(false);
  const px = sizes[size];
  const iconPx = size === 'sm' ? 14 : size === 'lg' ? 20 : 16;
  let bg = 'transparent';
  if (variant === 'solid') bg = disabled ? 'var(--neutral-100)' : 'var(--accent-primary)';
  else if (active) bg = 'var(--neutral-100)';
  else if (hover && !disabled) bg = 'var(--neutral-50)';
  const color = variant === 'solid' ? 'var(--fg-inverse)' : disabled ? 'var(--neutral-300)' : 'var(--fg-secondary)';
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: px, height: px, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        border: 'none', borderRadius: 'var(--radius-sm)', background: bg, cursor: disabled ? 'not-allowed' : 'pointer',
        transition: 'background var(--duration-fast) var(--ease-standard)', ...style,
      }}
    >
      <Icon name={name} size={iconPx} color={color} />
    </button>
  );
}
