Underline tab bar — switch between views within one screen (e.g. Overview / Revenue / Costs).

```jsx
<Tabs tabs={[{label:'Overview',value:'ov'},{label:'Revenue',value:'rev'}]} value={v} onChange={setV} />
```
