import React from 'react';
/**
 * Tabs — underline tab bar for switching views within a screen (report ranges, settings sections).
 * @startingPoint section="Navigation" subtitle="Underline tab bar" viewport="500x80"
 */
export interface TabItem { label: string; value: string; }
export interface TabsProps {
  tabs: TabItem[];
  value: string;
  onChange?: (value: string) => void;
}
