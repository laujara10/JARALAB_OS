import React from 'react';

export function Tabs({ tabs = [], value, onChange }) {
  return (
    <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border-subtle)', fontFamily: 'var(--font-sans)' }}>
      {tabs.map(t => {
        const active = t.value === value;
        return (
          <button
            key={t.value} type="button" onClick={() => onChange && onChange(t.value)}
            style={{
              padding: '10px 4px', marginRight: 20, border: 'none', background: 'transparent', cursor: 'pointer',
              fontSize: '0.875rem', fontWeight: 500,
              color: active ? 'var(--fg-primary)' : 'var(--fg-tertiary)',
              borderBottom: `2px solid ${active ? 'var(--accent-primary)' : 'transparent'}`,
              marginBottom: -1, transition: 'color var(--duration-fast) var(--ease-standard)',
            }}
          >{t.label}</button>
        );
      })}
    </div>
  );
}
