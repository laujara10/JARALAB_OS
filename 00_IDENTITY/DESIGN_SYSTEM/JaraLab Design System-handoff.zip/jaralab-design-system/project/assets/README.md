# Assets

**No logo, icon set, illustrations, or imagery were provided** with this brief — this design system was authored from a written brand brief only. Nothing here is a fabricated brand mark.

## Icons

Substituted with [Lucide](https://lucide.dev) icons, linked live from the `unpkg` CDN (`https://unpkg.com/lucide-static@latest/icons/<name>.svg`) — no local files to keep in sync. The `Icon` component (`components/core/Icon.jsx`) applies each SVG as a CSS `mask-image` so it inherits `currentColor` and any size, rather than embedding a fixed-color `<img>`. Pick names from the [Lucide icon list](https://lucide.dev/icons). If JaraLab has its own icon set (font, sprite, or SVGs), attach it and this system should switch to it — see readme.md Caveats.

## Logo / wordmark

No mark exists yet. Everywhere a logo would appear, render the plain wordmark:

```jsx
<span style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: '1.125rem', letterSpacing: 'var(--tracking-tight)' }}>JaraLab</span>
```

## Imagery

None provided. UI kits that call for photography (marketing hero, report covers) use a flat neutral placeholder block with a caption noting what real image should go there — never a generated or stock substitute.
