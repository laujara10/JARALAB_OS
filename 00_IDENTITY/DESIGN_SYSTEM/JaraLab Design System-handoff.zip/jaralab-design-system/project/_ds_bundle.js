/* @ds-bundle: {"format":4,"namespace":"JaraLabDesignSystem_424ac8","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Sparkline","sourcePath":"components/data/Sparkline.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Table","sourcePath":"components/data/Table.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"c17a614222b9","components/core/Button.jsx":"13d77a38206c","components/core/Card.jsx":"095d451c00d8","components/core/Icon.jsx":"fd22de58d2b0","components/core/IconButton.jsx":"1a176b5d142e","components/core/Tag.jsx":"9ace2dad889f","components/data/Sparkline.jsx":"d32eaf70aa36","components/data/StatCard.jsx":"ebdaece7b8be","components/data/Table.jsx":"880c9ce6e011","components/feedback/Dialog.jsx":"85e3a2d9c9cb","components/feedback/Toast.jsx":"1cadb8d3b826","components/feedback/Tooltip.jsx":"dc8284cec6c1","components/forms/Checkbox.jsx":"6b2dfabc406e","components/forms/Input.jsx":"ebefb124d969","components/forms/Radio.jsx":"387e45102b7b","components/forms/Select.jsx":"c9e3bef8bfd4","components/forms/Switch.jsx":"3ff056dc41eb","components/navigation/Tabs.jsx":"d2d30f992c5a","ui_kits/copilot/CopilotScreen.part.js":"0c08f15faf2c","ui_kits/dashboard/DashboardScreen.part.js":"8b6a0c1058b9","ui_kits/dashboard/Sidebar.part.js":"ca729a41e0ad","ui_kits/dashboard/Topbar.part.js":"83e57c19deeb","ui_kits/marketing/MarketingHome.part.js":"5142d1a9cd01"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.JaraLabDesignSystem_424ac8 = window.JaraLabDesignSystem_424ac8 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
const tones = {
  neutral: {
    bg: 'var(--neutral-100)',
    fg: 'var(--neutral-700)'
  },
  primary: {
    bg: 'var(--primary-50)',
    fg: 'var(--primary-700)'
  },
  success: {
    bg: 'var(--success-100)',
    fg: 'oklch(0.38 0.11 152)'
  },
  warning: {
    bg: 'var(--warning-100)',
    fg: 'oklch(0.45 0.13 75)'
  },
  danger: {
    bg: 'var(--danger-100)',
    fg: 'oklch(0.42 0.18 25)'
  },
  gold: {
    bg: 'var(--gold-50)',
    fg: 'var(--gold-700)'
  }
};
function Badge({
  children,
  tone = 'neutral',
  dot = false
}) {
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '3px 9px',
      borderRadius: 'var(--radius-full)',
      background: t.bg,
      color: t.fg,
      fontFamily: 'var(--font-sans)',
      fontWeight: 500,
      fontSize: '0.75rem',
      lineHeight: 1.3
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: t.fg
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizeStyles = {
  sm: {
    padding: '0 var(--space-3)',
    height: 30,
    fontSize: '0.8125rem',
    gap: 6
  },
  md: {
    padding: '0 var(--space-4)',
    height: 36,
    fontSize: '0.875rem',
    gap: 8
  },
  lg: {
    padding: '0 var(--space-5)',
    height: 44,
    fontSize: '0.9375rem',
    gap: 8
  }
};
function variantStyle(variant, disabled) {
  if (disabled) {
    return {
      background: 'var(--neutral-100)',
      color: 'var(--neutral-400)',
      border: '1px solid var(--neutral-100)'
    };
  }
  switch (variant) {
    case 'secondary':
      return {
        background: 'var(--bg-surface)',
        color: 'var(--fg-primary)',
        border: '1px solid var(--border-default)'
      };
    case 'ghost':
      return {
        background: 'transparent',
        color: 'var(--fg-primary)',
        border: '1px solid transparent'
      };
    case 'danger':
      return {
        background: 'var(--danger-500)',
        color: 'var(--fg-inverse)',
        border: '1px solid var(--danger-500)'
      };
    case 'gold':
      return {
        background: 'var(--accent-gold)',
        color: 'var(--neutral-900)',
        border: '1px solid var(--accent-gold)'
      };
    case 'primary':
    default:
      return {
        background: 'var(--accent-primary)',
        color: 'var(--fg-inverse)',
        border: '1px solid var(--accent-primary)'
      };
  }
}
function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconRight,
  disabled = false,
  onClick,
  type = 'button',
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const base = variantStyle(variant, disabled);
  let bg = base.background;
  if (!disabled && hover) {
    if (variant === 'primary') bg = 'var(--accent-primary-hover)';else if (variant === 'secondary') bg = 'var(--neutral-50)';else if (variant === 'ghost') bg = 'var(--neutral-50)';else if (variant === 'danger') bg = 'oklch(0.48 0.20 25)';else if (variant === 'gold') bg = 'var(--gold-600)';
  }
  if (!disabled && active) {
    if (variant === 'primary') bg = 'var(--accent-primary-active)';
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-sans)',
      fontWeight: 500,
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background var(--duration-fast) var(--ease-standard), transform var(--duration-fast) var(--ease-standard)',
      transform: active && !disabled ? 'translateY(1px)' : 'none',
      ...sizeStyles[size],
      ...base,
      background: bg,
      ...style
    }
  }, rest), icon, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  children,
  padding = 'md',
  hoverable = false,
  style = {}
}) {
  const [hover, setHover] = React.useState(false);
  const pad = {
    sm: 'var(--space-4)',
    md: 'var(--space-6)',
    lg: 'var(--space-8)'
  }[padding];
  return /*#__PURE__*/React.createElement("div", {
    onMouseEnter: () => hoverable && setHover(true),
    onMouseLeave: () => hoverable && setHover(false),
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: pad,
      boxShadow: hover ? 'var(--shadow-md)' : 'var(--shadow-xs)',
      transition: 'box-shadow var(--duration-standard) var(--ease-standard)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Icon({
  name,
  size = 20,
  color = 'currentColor',
  strokeWidth,
  className = '',
  style = {},
  ...rest
}) {
  const url = `https://unpkg.com/lucide-static@0.469.0/icons/${name}.svg`;
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "img",
    "aria-label": rest['aria-label'] || name,
    className: `jl-icon ${className}`,
    style: {
      display: 'inline-block',
      width: size,
      height: size,
      flex: '0 0 auto',
      backgroundColor: color,
      WebkitMaskImage: `url(${url})`,
      maskImage: `url(${url})`,
      WebkitMaskSize: '100% 100%',
      maskSize: '100% 100%',
      WebkitMaskRepeat: 'no-repeat',
      maskRepeat: 'no-repeat',
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
const sizes = {
  sm: 28,
  md: 34,
  lg: 40
};
function IconButton({
  name,
  size = 'md',
  variant = 'ghost',
  active = false,
  disabled = false,
  label,
  onClick,
  style = {}
}) {
  const [hover, setHover] = React.useState(false);
  const px = sizes[size];
  const iconPx = size === 'sm' ? 14 : size === 'lg' ? 20 : 16;
  let bg = 'transparent';
  if (variant === 'solid') bg = disabled ? 'var(--neutral-100)' : 'var(--accent-primary)';else if (active) bg = 'var(--neutral-100)';else if (hover && !disabled) bg = 'var(--neutral-50)';
  const color = variant === 'solid' ? 'var(--fg-inverse)' : disabled ? 'var(--neutral-300)' : 'var(--fg-secondary)';
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: px,
      height: px,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: 'none',
      borderRadius: 'var(--radius-sm)',
      background: bg,
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background var(--duration-fast) var(--ease-standard)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: name,
    size: iconPx,
    color: color
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function Tag({
  children,
  onRemove,
  selected = false
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 10px',
      borderRadius: 'var(--radius-sm)',
      background: selected ? 'var(--primary-50)' : 'var(--bg-surface-2)',
      border: `1px solid ${selected ? 'var(--border-accent)' : 'var(--border-default)'}`,
      color: selected ? 'var(--primary-700)' : 'var(--fg-secondary)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 500,
      fontSize: '0.8125rem'
    }
  }, children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: onRemove,
    style: {
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      padding: 0,
      display: 'flex',
      color: 'inherit',
      opacity: 0.6
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/Sparkline.jsx
try { (() => {
function Sparkline({
  data = [],
  width = 120,
  height = 36,
  color = 'var(--accent-primary)',
  fill = true,
  responsive = false
}) {
  if (!data.length) return null;
  const min = Math.min(...data),
    max = Math.max(...data);
  const range = max - min || 1;
  const step = width / (data.length - 1 || 1);
  const pts = data.map((d, i) => [i * step, height - (d - min) / range * height]);
  const line = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
  const area = `${line} L${width},${height} L0,${height} Z`;
  return /*#__PURE__*/React.createElement("svg", {
    width: responsive ? '100%' : width,
    height: height,
    viewBox: `0 0 ${width} ${height}`,
    preserveAspectRatio: "none",
    style: responsive ? {
      display: 'block'
    } : undefined
  }, fill && /*#__PURE__*/React.createElement("path", {
    d: area,
    fill: color,
    opacity: "0.12"
  }), /*#__PURE__*/React.createElement("path", {
    d: line,
    fill: "none",
    stroke: color,
    strokeWidth: "1.75",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }));
}
Object.assign(__ds_scope, { Sparkline });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Sparkline.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
function StatCard({
  label,
  value,
  delta,
  deltaTone = 'success',
  caption
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-5)',
      boxShadow: 'var(--shadow-xs)',
      fontFamily: 'var(--font-sans)',
      minWidth: 160
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.8125rem',
      color: 'var(--fg-secondary)',
      marginBottom: 8
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '1.75rem',
      fontWeight: 600,
      color: 'var(--fg-primary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, value), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.8125rem',
      fontWeight: 500,
      color: deltaTone === 'success' ? 'oklch(0.42 0.11 152)' : deltaTone === 'danger' ? 'oklch(0.48 0.18 25)' : 'var(--fg-tertiary)'
    }
  }, delta)), caption && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.75rem',
      color: 'var(--fg-tertiary)',
      marginTop: 6
    }
  }, caption));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/data/Table.jsx
try { (() => {
function Table({
  columns = [],
  rows = []
}) {
  return /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '8px 12px',
      fontSize: '0.6875rem',
      fontWeight: 500,
      color: 'var(--fg-tertiary)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-wide)',
      borderBottom: '1px solid var(--border-default)'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: i,
    style: {
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    style: {
      textAlign: c.align || 'left',
      padding: '10px 12px',
      fontSize: '0.8125rem',
      color: 'var(--fg-primary)',
      fontFamily: c.mono ? 'var(--font-mono)' : 'inherit',
      fontVariantNumeric: c.mono ? 'tabular-nums' : 'normal'
    }
  }, r[c.key]))))));
}
Object.assign(__ds_scope, { Table });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Table.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  title,
  children,
  onClose,
  actions
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'oklch(0.2 0.02 55 / 0.4)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 50
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      width: 420,
      maxWidth: '90%',
      padding: 'var(--space-6)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '1.0625rem',
      fontWeight: 600,
      color: 'var(--fg-primary)'
    }
  }, title), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--fg-tertiary)',
      cursor: 'pointer',
      fontSize: 18
    }
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.875rem',
      color: 'var(--fg-secondary)',
      lineHeight: 1.55
    }
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 8,
      marginTop: 20
    }
  }, actions)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const tones = {
  info: {
    bg: 'var(--neutral-900)',
    icon: 'info',
    color: 'var(--neutral-0)'
  },
  success: {
    bg: 'var(--neutral-900)',
    icon: 'check-circle-2',
    color: 'var(--success-500)'
  },
  warning: {
    bg: 'var(--neutral-900)',
    icon: 'alert-triangle',
    color: 'var(--warning-500)'
  },
  danger: {
    bg: 'var(--neutral-900)',
    icon: 'alert-circle',
    color: 'var(--danger-500)'
  }
};
function Toast({
  tone = 'info',
  title,
  description,
  onClose
}) {
  const t = tones[tone] || tones.info;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 10,
      background: t.bg,
      color: 'var(--neutral-0)',
      padding: 'var(--space-3) var(--space-4)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)',
      minWidth: 280,
      maxWidth: 360,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: t.color,
      flex: '0 0 auto',
      marginTop: 3
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.875rem',
      fontWeight: 600
    }
  }, title), description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.8125rem',
      color: 'var(--neutral-300)',
      marginTop: 2
    }
  }, description)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      border: 'none',
      background: 'transparent',
      color: 'var(--neutral-400)',
      cursor: 'pointer',
      fontSize: 16,
      lineHeight: 1,
      padding: 0
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  children,
  label,
  side = 'top'
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginBottom: 6
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginTop: 6
    }
  }[side] || {};
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      ...pos,
      whiteSpace: 'nowrap',
      padding: '5px 9px',
      background: 'var(--neutral-900)',
      color: 'var(--neutral-0)',
      borderRadius: 'var(--radius-sm)',
      fontSize: '0.75rem',
      fontFamily: 'var(--font-sans)',
      boxShadow: 'var(--shadow-md)',
      zIndex: 20,
      pointerEvents: 'none'
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked = false,
  onChange,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-sans)',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: 5,
      flex: '0 0 auto',
      border: `1px solid ${checked ? 'var(--accent-primary)' : 'var(--border-strong)'}`,
      background: checked ? 'var(--accent-primary)' : 'var(--bg-surface)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--duration-fast) var(--ease-standard)'
    }
  }, checked && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "9",
    viewBox: "0 0 11 9",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1 4.5L4 7.5L10 1",
    stroke: "white",
    strokeWidth: "1.6",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      display: 'none'
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.875rem',
      color: 'var(--fg-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  error,
  icon,
  disabled = false,
  size = 'md'
}) {
  const [focus, setFocus] = React.useState(false);
  const h = size === 'sm' ? 32 : 38;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.8125rem',
      fontWeight: 500,
      color: 'var(--fg-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: h,
      padding: '0 var(--space-3)',
      borderRadius: 'var(--radius-sm)',
      background: disabled ? 'var(--neutral-50)' : 'var(--bg-surface)',
      border: `1px solid ${error ? 'var(--danger-500)' : focus ? 'var(--border-strong)' : 'var(--border-default)'}`,
      boxShadow: focus && !error ? 'var(--shadow-focus)' : 'none',
      transition: 'box-shadow var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)'
    }
  }, icon, /*#__PURE__*/React.createElement("input", {
    type: type,
    value: value,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      border: 'none',
      outline: 'none',
      background: 'transparent',
      flex: 1,
      fontSize: '0.875rem',
      color: 'var(--fg-primary)',
      fontFamily: 'inherit'
    }
  })), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.75rem',
      color: 'var(--danger-500)'
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  label,
  checked = false,
  onChange,
  name,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      cursor: disabled ? 'not-allowed' : 'pointer',
      fontFamily: 'var(--font-sans)',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      borderRadius: '50%',
      flex: '0 0 auto',
      border: `1px solid ${checked ? 'var(--accent-primary)' : 'var(--border-strong)'}`,
      background: 'var(--bg-surface)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: 'var(--accent-primary)'
    }
  })), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      display: 'none'
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.875rem',
      color: 'var(--fg-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  value,
  onChange,
  options = [],
  disabled = false
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.8125rem',
      fontWeight: 500,
      color: 'var(--fg-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 38,
      borderRadius: 'var(--radius-sm)',
      background: disabled ? 'var(--neutral-50)' : 'var(--bg-surface)',
      border: `1px solid ${focus ? 'var(--border-strong)' : 'var(--border-default)'}`,
      boxShadow: focus ? 'var(--shadow-focus)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: value,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: '100%',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      padding: '0 32px 0 var(--space-3)',
      fontSize: '0.875rem',
      color: 'var(--fg-primary)',
      fontFamily: 'inherit',
      appearance: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 10,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--fg-tertiary)',
      fontSize: 10
    }
  }, "\u25BE")));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  checked = false,
  onChange,
  disabled = false,
  label
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 36,
      height: 21,
      borderRadius: 'var(--radius-full)',
      padding: 2,
      display: 'flex',
      background: checked ? 'var(--accent-primary)' : 'var(--neutral-200)',
      transition: 'background var(--duration-standard) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 17,
      height: 17,
      borderRadius: '50%',
      background: 'white',
      boxShadow: 'var(--shadow-sm)',
      transform: checked ? 'translateX(15px)' : 'translateX(0)',
      transition: 'transform var(--duration-standard) var(--ease-out)'
    }
  })), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      display: 'none'
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.875rem',
      color: 'var(--fg-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  tabs = [],
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)'
    }
  }, tabs.map(t => {
    const active = t.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      type: "button",
      onClick: () => onChange && onChange(t.value),
      style: {
        padding: '10px 4px',
        marginRight: 20,
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        fontSize: '0.875rem',
        fontWeight: 500,
        color: active ? 'var(--fg-primary)' : 'var(--fg-tertiary)',
        borderBottom: `2px solid ${active ? 'var(--accent-primary)' : 'transparent'}`,
        marginBottom: -1,
        transition: 'color var(--duration-fast) var(--ease-standard)'
      }
    }, t.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/copilot/CopilotScreen.part.js
try { (() => {
const SUGGESTIONS = ['Why did food cost go up this week?', 'Summarize this month vs last month', 'Which vendor is over budget?'];
const SEED_MESSAGES = [{
  role: 'assistant',
  text: "I'm your JaraLab copilot. Ask me about revenue, costs, labor, or vendors — I read straight from your POS and invoices."
}];
function CopilotScreen() {
  const {
    IconButton,
    Icon,
    Badge
  } = window.JaraLabDesignSystem_424ac8;
  const [messages, setMessages] = React.useState(SEED_MESSAGES);
  const [input, setInput] = React.useState('');
  const scrollRef = React.useRef(null);
  const send = text => {
    const t = (text ?? input).trim();
    if (!t) return;
    setMessages(m => [...m, {
      role: 'user',
      text: t
    }]);
    setInput('');
    setTimeout(() => {
      setMessages(m => [...m, {
        role: 'assistant',
        text: 'Food cost is up 3.2% this week ($2,140). Local Farms Co-op invoices rose 8% month over month — that vendor alone is $840 over its typical weekly spend.',
        stat: {
          label: 'Food cost',
          value: '28.4%',
          delta: '+1.1pt'
        }
      }]);
    }, 500);
  };
  React.useEffect(() => {
    scrollRef.current?.scrollTo(0, scrollRef.current.scrollHeight);
  }, [messages]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: scrollRef,
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 'var(--space-8) var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      maxWidth: 720,
      margin: '0 auto',
      width: '100%'
    }
  }, messages.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-start',
      flexDirection: m.role === 'user' ? 'row-reverse' : 'row'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: '50%',
      flex: '0 0 auto',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: m.role === 'user' ? 'var(--neutral-800)' : 'var(--primary-600)',
      color: 'var(--neutral-0)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: m.role === 'user' ? 'user' : 'sparkles',
    size: 14,
    color: "white"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 520
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: m.role === 'user' ? 'var(--neutral-900)' : 'var(--bg-surface)',
      color: m.role === 'user' ? 'var(--neutral-0)' : 'var(--fg-primary)',
      border: m.role === 'user' ? 'none' : '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: '12px 16px',
      fontFamily: 'var(--font-sans)',
      fontSize: '0.875rem',
      lineHeight: 1.55
    }
  }, m.text), m.stat && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: '8px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.6875rem',
      color: 'var(--fg-tertiary)',
      marginBottom: 2
    }
  }, m.stat.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '1rem',
      fontWeight: 600
    }
  }, m.stat.value, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.75rem',
      color: 'oklch(0.48 0.18 25)'
    }
  }, m.stat.delta))))))), messages.length === 1 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      marginTop: 8
    }
  }, SUGGESTIONS.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    onClick: () => send(s),
    style: {
      textAlign: 'left',
      padding: '10px 14px',
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--border-default)',
      background: 'var(--bg-surface)',
      fontFamily: 'var(--font-sans)',
      fontSize: '0.8125rem',
      color: 'var(--fg-secondary)',
      cursor: 'pointer'
    }
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      padding: 'var(--space-4) var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: '0 auto',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-lg)',
      padding: '8px 8px 8px 16px',
      background: 'var(--bg-surface)'
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: input,
    onChange: e => setInput(e.target.value),
    placeholder: "Ask about your numbers\u2026",
    onKeyDown: e => e.key === 'Enter' && send(),
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      fontFamily: 'var(--font-sans)',
      fontSize: '0.875rem',
      background: 'transparent'
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    name: "send",
    label: "Send",
    variant: "solid",
    onClick: () => send()
  }))));
}
window.CopilotScreen = CopilotScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/copilot/CopilotScreen.part.js", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/DashboardScreen.part.js
try { (() => {
const EXPENSES = [{
  name: 'Sysco',
  cat: 'Produce',
  amt: '$4,280.00',
  flag: null
}, {
  name: 'US Foods',
  cat: 'Dry goods',
  amt: '$2,910.50',
  flag: null
}, {
  name: 'Restaurant Depot',
  cat: 'Paper & supplies',
  amt: '$1,120.00',
  flag: null
}, {
  name: 'Ecolab',
  cat: 'Cleaning',
  amt: '$640.25',
  flag: null
}, {
  name: 'Local Farms Co-op',
  cat: 'Produce',
  amt: '$6,120.00',
  flag: 'over'
}];
function DashboardScreen({
  section
}) {
  const {
    StatCard,
    Sparkline,
    Table,
    Badge,
    Tabs,
    Icon
  } = window.JaraLabDesignSystem_424ac8;
  const [tab, setTab] = React.useState('overview');
  const rows = EXPENSES.map(e => ({
    name: e.name,
    cat: /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, e.cat),
    amt: e.amt,
    status: e.flag === 'over' ? /*#__PURE__*/React.createElement(Badge, {
      tone: "warning",
      dot: true
    }, "Over budget") : /*#__PURE__*/React.createElement(Badge, {
      tone: "success",
      dot: true
    }, "On track")
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-8) var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      maxWidth: 1100
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-serif)',
      fontSize: '1.75rem',
      fontStyle: 'italic',
      color: 'var(--fg-primary)',
      marginBottom: 4
    }
  }, "\"Your food cost is up 3.2% this week. Produce is the driver.\""), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '0.8125rem',
      color: 'var(--fg-tertiary)'
    }
  }, "JaraLab AI \xB7 generated from this week's invoices")), /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      label: 'Overview',
      value: 'overview'
    }, {
      label: 'Revenue',
      value: 'revenue'
    }, {
      label: 'Costs',
      value: 'costs'
    }, {
      label: 'Labor',
      value: 'labor'
    }],
    value: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Revenue",
    value: "$84,210",
    delta: "+4.8%",
    deltaTone: "success",
    caption: "vs. last month"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Food cost %",
    value: "28.4%",
    delta: "+1.1pt",
    deltaTone: "danger",
    caption: "vs. last month"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Labor %",
    value: "31.2%",
    delta: "-0.4pt",
    deltaTone: "success",
    caption: "vs. last month"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Net margin",
    value: "14.6%",
    delta: "+0.6pt",
    deltaTone: "success",
    caption: "vs. last month"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-6)',
      boxShadow: 'var(--shadow-xs)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: '0.9375rem',
      color: 'var(--fg-primary)'
    }
  }, "Revenue, last 8 weeks"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '0.8125rem',
      color: 'var(--fg-secondary)'
    }
  }, "$84,210 ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'oklch(0.42 0.11 152)'
    }
  }, "+4.8%"))), /*#__PURE__*/React.createElement(Sparkline, {
    data: [62000, 68000, 65000, 71000, 76000, 74000, 80000, 84210],
    width: 1000,
    height: 90,
    responsive: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-6)',
      boxShadow: 'var(--shadow-xs)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: '0.9375rem',
      color: 'var(--fg-primary)',
      marginBottom: 'var(--space-3)'
    }
  }, "Vendor expenses this week"), /*#__PURE__*/React.createElement(Table, {
    columns: [{
      key: 'name',
      label: 'Vendor'
    }, {
      key: 'cat',
      label: 'Category'
    }, {
      key: 'amt',
      label: 'Amount',
      align: 'right',
      mono: true
    }, {
      key: 'status',
      label: 'Status',
      align: 'right'
    }],
    rows: rows
  })));
}
window.DashboardScreen = DashboardScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/DashboardScreen.part.js", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Sidebar.part.js
try { (() => {
const NAV = [{
  key: 'overview',
  label: 'Overview',
  icon: 'layout-grid'
}, {
  key: 'revenue',
  label: 'Revenue',
  icon: 'trending-up'
}, {
  key: 'costs',
  label: 'Costs',
  icon: 'receipt'
}, {
  key: 'labor',
  label: 'Labor',
  icon: 'users'
}, {
  key: 'reports',
  label: 'Reports',
  icon: 'file-text'
}, {
  key: 'copilot',
  label: 'AI Copilot',
  icon: 'sparkles'
}];
function Sidebar({
  active,
  onSelect
}) {
  const {
    Icon
  } = window.JaraLabDesignSystem_424ac8;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 220,
      flex: '0 0 auto',
      borderRight: '1px solid var(--border-subtle)',
      background: 'var(--bg-surface)',
      display: 'flex',
      flexDirection: 'column',
      padding: 'var(--space-5) var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: 18,
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--fg-primary)',
      padding: '0 var(--space-2)',
      marginBottom: 'var(--space-6)'
    }
  }, "JaraLab"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, NAV.map(n => {
    const isActive = n.key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: n.key,
      onClick: () => onSelect(n.key),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        padding: '8px 10px',
        border: 'none',
        borderRadius: 'var(--radius-sm)',
        background: isActive ? 'var(--primary-50)' : 'transparent',
        color: isActive ? 'var(--primary-700)' : 'var(--fg-secondary)',
        fontFamily: 'var(--font-sans)',
        fontSize: '0.8125rem',
        fontWeight: 500,
        cursor: 'pointer',
        textAlign: 'left'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 16,
      color: isActive ? 'var(--primary-700)' : 'var(--fg-tertiary)'
    }), n.label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '10px',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 28,
      height: 28,
      borderRadius: '50%',
      background: 'var(--neutral-800)',
      color: 'var(--neutral-0)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 12,
      fontWeight: 600,
      fontFamily: 'var(--font-sans)'
    }
  }, "TK"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '0.75rem'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 500,
      color: 'var(--fg-primary)'
    }
  }, "Tino's Kitchen"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--fg-tertiary)'
    }
  }, "Owner"))));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Sidebar.part.js", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Topbar.part.js
try { (() => {
function Topbar({
  title,
  range,
  onRangeChange
}) {
  const {
    Select,
    IconButton,
    Icon
  } = window.JaraLabDesignSystem_424ac8;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 60,
      flex: '0 0 auto',
      borderBottom: '1px solid var(--border-subtle)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 var(--space-6)',
      background: 'oklch(0.995 0.002 80 / 0.85)',
      backdropFilter: 'blur(8px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      fontSize: '1.0625rem',
      color: 'var(--fg-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 160
    }
  }, /*#__PURE__*/React.createElement(Select, {
    value: range,
    onChange: e => onRangeChange(e.target.value),
    options: [{
      label: 'Last 7 days',
      value: '7d'
    }, {
      label: 'Last 30 days',
      value: '30d'
    }, {
      label: 'This quarter',
      value: 'q'
    }]
  })), /*#__PURE__*/React.createElement(IconButton, {
    name: "bell",
    label: "Notifications"
  }), /*#__PURE__*/React.createElement(IconButton, {
    name: "settings",
    label: "Settings"
  })));
}
window.Topbar = Topbar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Topbar.part.js", error: String((e && e.message) || e) }); }

// ui_kits/marketing/MarketingHome.part.js
try { (() => {
function MarketingHome() {
  const {
    Button,
    Icon,
    Badge
  } = window.JaraLabDesignSystem_424ac8;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      color: 'var(--fg-primary)',
      background: 'var(--bg-page)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px var(--space-8)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 18,
      letterSpacing: 'var(--tracking-tight)'
    }
  }, "JaraLab"), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 28,
      fontSize: '0.875rem',
      color: 'var(--fg-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "Product"), /*#__PURE__*/React.createElement("span", null, "Pricing"), /*#__PURE__*/React.createElement("span", null, "Customers"), /*#__PURE__*/React.createElement("span", null, "Company")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Log in"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm"
  }, "Get started"))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 760,
      margin: '0 auto',
      textAlign: 'center',
      padding: 'var(--space-32) var(--space-6) var(--space-16)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.75rem',
      fontWeight: 500,
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-widest)',
      color: 'var(--fg-tertiary)',
      marginBottom: 'var(--space-4)'
    }
  }, "AI-native restaurant intelligence"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: 'var(--text-display-xl)',
      letterSpacing: 'var(--tracking-tight)',
      margin: '0 0 var(--space-5)'
    }
  }, "Your margins, explained."), /*#__PURE__*/React.createElement("p", {
    style: {
      font: 'var(--text-body-lg)',
      color: 'var(--fg-secondary)',
      maxWidth: 520,
      margin: '0 auto var(--space-8)'
    }
  }, "Financial clarity, marketing strategy, and business intelligence for restaurant owners \u2014 powered by AI that reads your numbers so you don't have to."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg"
  }, "Get started free"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg"
  }, "Watch a 2-min demo"))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1040,
      margin: '0 auto',
      padding: '0 var(--space-6) var(--space-24)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-lg)',
      padding: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--neutral-50)',
      borderRadius: 'var(--radius-lg)',
      height: 380,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--fg-tertiary)',
      fontSize: '0.8125rem',
      border: '1px dashed var(--border-default)'
    }
  }, "Product screenshot placeholder \u2014 dashboard view"))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 1040,
      margin: '0 auto',
      padding: '0 var(--space-6) var(--space-24)',
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 'var(--space-8)'
    }
  }, [{
    icon: 'trending-up',
    title: 'Financial clarity',
    body: 'Real-time margins, food cost, and labor — explained in plain language, not spreadsheets.'
  }, {
    icon: 'sparkles',
    title: 'AI copilot',
    body: 'Ask questions about your business in plain English and get grounded, specific answers.'
  }, {
    icon: 'pie-chart',
    title: 'Business intelligence',
    body: 'Know which vendors, dayparts, and menu items actually drive profit.'
  }].map(f => /*#__PURE__*/React.createElement("div", {
    key: f.title
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-md)',
      background: 'var(--primary-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: f.icon,
    size: 20,
    color: "var(--primary-600)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: '1rem',
      marginBottom: 6
    }
  }, f.title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.875rem',
      color: 'var(--fg-secondary)',
      lineHeight: 1.55
    }
  }, f.body)))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--neutral-900)',
      color: 'var(--neutral-0)',
      padding: 'var(--space-24) var(--space-6)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--text-editorial-lg)',
      fontStyle: 'italic',
      maxWidth: 620,
      margin: '0 auto var(--space-4)'
    }
  }, "\"JaraLab told us our produce vendor was quietly eating 2 points of margin. We caught it in week one.\""), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.8125rem',
      color: 'var(--neutral-400)'
    }
  }, "Owner, independent restaurant group")), /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: 'var(--space-10) var(--space-8)',
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: '0.8125rem',
      color: 'var(--fg-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("div", null, "\xA9 2026 JaraLab"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("span", null, "Privacy"), /*#__PURE__*/React.createElement("span", null, "Terms"), /*#__PURE__*/React.createElement("span", null, "Contact"))));
}
window.MarketingHome = MarketingHome;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/MarketingHome.part.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Sparkline = __ds_scope.Sparkline;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Table = __ds_scope.Table;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
